def handler(event, context):
    print("I ran")

    return {"A response"}